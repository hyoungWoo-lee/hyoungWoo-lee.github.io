package com.example.myfirstapp;

import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.os.Bundle;


import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView mWebView;

    private String myUrl = "http://";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mWebView = (WebView) findViewById(R.id.webview);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.loadUrl("https://github.com/hyoungWoo-lee/hyoungWoo-lee.github.io");
        mWebView.setWebChromeClient(new WebChromeClient());
    }
}
